# -*- coding: utf-8 -*-
"""
Created on Fri Apr 10 15:19:18 2020

@author: HP
"""

# import libraries
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.utils.data
import csv
import random
np.random.seed(100)
torch.manual_seed(100)


 


data=[]
with open('Anger.csv',encoding='utf-8') as csvfile:
  spamreader = csv.reader(csvfile)
  for row in spamreader:
      data.append(row)
data=data[1:]
raw_data=[x[2:] for x in data ]
for ele in raw_data:
    if ele[-1]=='Genuine':
        ele[-1]=0
    else:
        ele[-1]=1
    dim=len(ele)
    for i in range(dim):
        ele[i]=float(ele[i])
random.Random(98).shuffle(raw_data)      
raw_data=np.array(raw_data)
#raw_data=(raw_data-raw_data.min(0))/(raw_data.max(0)-raw_data.min(0))
raw_data=list(raw_data)
train_data=np.array(raw_data[:int(0.8*len(raw_data))])
#train_data=(train_data-train_data.min(0))/(train_data.max(0)-train_data.min(0))
test_data  = np.array(raw_data[int(0.8*len(raw_data)):])
#test_data=(test_data-test_data.min(0))/(test_data.max(0)-test_data.min(0))

#np.save('train.npy',train_data)
#np.save('test.npy',test_data)


      