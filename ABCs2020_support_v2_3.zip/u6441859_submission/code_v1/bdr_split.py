# -*- coding: utf-8 -*-
"""
Created on Sun Apr 12 23:17:02 2020

@author: HP
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.utils.data
import random
from matplotlib import pyplot as plt
import torch.nn.functional as F
import csv
torch.manual_seed(100)
np.random.seed(100)
# Hyper Parameters
input_size = 6
hidden_size = 60
num_classes = 2
num_epochs = 1000
batch_size = 10
learning_rate = 0.005
alpha=0.9
bdr=1
early_stop=1
stop_thresh=0.05


# define a customise torch dataset
class DataFrameDataset(torch.utils.data.Dataset):
    def __init__(self, data_array):
        self.data_tensor = torch.Tensor(data_array)
       
    # a function to get items by index
    def __getitem__(self, index):
        obj = self.data_tensor[index]
        input = self.data_tensor[index][0:-1]
        target = self.data_tensor[index][-1]
       
       
        return input, target

    # a function to count samples
    def __len__(self):
        n, _ = self.data_tensor.shape
        return n

 # Neural Network
class Net(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.activate = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        out = self.fc1(x)
        out = self.activate(out)
        out = self.fc2(out)
        return out


net = Net(input_size, hidden_size, num_classes)
# Loss and Optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate,weight_decay=1e-5)

data=[]
with open('Anger.csv',encoding='utf-8') as csvfile:
  spamreader = csv.reader(csvfile)
  for row in spamreader:
      data.append(row)
data=data[1:]
raw_data=[x[2:] for x in data ]
for ele in raw_data:
    if ele[-1]=='Genuine':
        ele[-1]=0
    else:
        ele[-1]=1
    dim=len(ele)
    for i in range(dim):
        ele[i]=float(ele[i])
random.Random(98).shuffle(raw_data)      
raw_data=np.array(raw_data)


# train the model by batch
if __name__=='__main__':
    var_list=[]
    all_losses = []
    test_losses=[]
    train_acc_list=[]
    test_acc_list=[]
    trigger=[]
    for epoch in range(num_epochs):
        total = 0
        correct = 0
        total_loss = 0
        
           
        X = torch.tensor(raw_data[:,:-1]).float()
        Y = torch.tensor(raw_data[:,-1]).long()

        # Forward + Backward + Optimize
        optimizer.zero_grad()  # zero the gradient buffer
        outputs = net(X)
        loss = criterion(outputs, Y)
        
        loss.backward()
        optimizer.step()
        prob=F.softmax(outputs,1)
        raw, predicted = torch.max(F.softmax(outputs,1),1)
        # calculate and print accuracy
        total = total + predicted.size(0)
        correct_mask=predicted.data.numpy() == Y.data.numpy()
        correct = correct + sum(predicted.data.numpy() == Y.data.numpy())
        total_loss = total_loss + loss.item()
        mean_loss=total_loss/(X.shape[0])
        
        if epoch%1==0:
            print('Epoch [%d/%d], Loss: %.4f, Accuracy: %.2f %%'
              % (epoch , num_epochs,
                 total_loss, 100 * correct/total))
            all_losses.append([epoch,mean_loss])
            train_acc_list.append([epoch,correct/total])
        #filter_loader = torch.utils.data.DataLoader(train_dataset, batch_size=1, shuffle=False)
        sample_errors=[]
        mean_error=0
       # print('doing error statistic')
        prob=[k.item() for k in raw]
        
        error=[-prob[i] if correct_mask[i] else prob[i] for i in range(Y.shape[0])]
      
            
        sample_errors=np.array(error)
        sample_errors=(sample_errors-sample_errors.min())/(sample_errors.max()-sample_errors.min())
        mean_error=np.mean(sample_errors)
        var=sample_errors.var()  
        var_list.append(var)
       
        if var<=stop_thresh and early_stop==1:
#            np.save('alpha_'+str(alpha)+'.npy',train_data)
            print("pattern left:",raw_data.shape[0])
            break
        if (epoch % 50 == 0 and epoch>0 and bdr==1 and var<=0.12):   
            sub_errors=[ele for ele in sample_errors if ele > mean_error]
            sub_mean_error=sum(sub_errors)/len(sub_errors)
            sub_error_std=np.std(np.array(sub_errors))
            threshold=sub_mean_error+alpha*sub_error_std     
            sample_errors=np.array(sample_errors)
            mask_idx=np.where(sample_errors<threshold)[0]
            raw_data=raw_data[mask_idx]
            trigger.append([epoch,var])
            
    raw_data=(raw_data-raw_data.min(0))/(raw_data.max(0)-raw_data.min(0))
    raw_data=list(raw_data)
    train_data=np.array(raw_data[:int(0.8*len(raw_data))])

    test_data  = np.array(raw_data[int(0.8*len(raw_data)):])


    np.save('bdr_train.npy',train_data)
    np.save('bdr_test.npy',test_data)
    
         
           
            
  
    
  