"""
This script contains the experiment code of the project
Some of the code are inspired by the COMP8420 Lab code
"""

# import libraries
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.utils.data
import random
from matplotlib import pyplot as plt
import torch.nn.functional as F
torch.manual_seed(100)
np.random.seed(100)
# Hyper Parameters
input_size = 6
hidden_size = 60
num_classes = 2
num_epochs = 1000
batch_size = 10
learning_rate = 0.005
alpha=0.5    #std distance
bdr=1       # make it as 1 if you want to use BDR
early_stop=1 # make it as 1 if you want to use BDR
stop_thresh=0.01 #training stop variance threshold
npattern=0 #number of Artificial outlier

# define a customise torch dataset, this is from the glass-reocognition code of 
# 8420 LAB
class DataFrameDataset(torch.utils.data.Dataset):
    def __init__(self, data_array):
        self.data_tensor = torch.Tensor(data_array)
       
    # a function to get items by index
    def __getitem__(self, index):
        obj = self.data_tensor[index]
        input = self.data_tensor[index][0:-1]
        target = self.data_tensor[index][-1]
       
       
        return input, target

    # a function to count samples
    def __len__(self):
        n, _ = self.data_tensor.shape
        return n

 # Neural Network,the skeleton is from the lab code
class Net(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.activate = nn.ReLU()    #the activation function can be changed
        self.fc2 = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        out = self.fc1(x)
        out = self.activate(out)
        out = self.fc2(out)
        return out


net = Net(input_size, hidden_size, num_classes)
# Loss and Optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate,weight_decay=1e-5)

train_data=np.load('train.npy')
if npattern:
    train_data[:npattern,:-1]=-100  #create Artificial outliers


test_data=np.load('test.npy')


# train the model by batch
if __name__=='__main__':
    var_list=[]
    all_losses = []
    test_losses=[]
    train_acc_list=[]
    test_acc_list=[]
    trigger=[]
    for epoch in range(num_epochs):   #training part, inspired by the lab code
        total = 0
        correct = 0
        total_loss = 0
        train_dataset = DataFrameDataset(train_data)
        X = torch.tensor(train_data[:,:-1]).float()
        Y = torch.tensor(train_data[:,-1]).long()
        
        
        optimizer.zero_grad()  
        outputs = net(X)
        loss = criterion(outputs, Y)
        
        loss.backward()
        optimizer.step()
        prob=F.softmax(outputs,1)
        raw, predicted = torch.max(F.softmax(outputs,1),1) #use softmax to produce probability
        # calculate and print accuracy
        total = total + predicted.size(0)
        correct_mask=predicted.data.numpy() == Y.data.numpy()
        correct = correct + sum(predicted.data.numpy() == Y.data.numpy())
        total_loss = total_loss + loss.item()
        mean_loss=total_loss/(X.shape[0])
        
        if epoch%1==0:
            print('Epoch [%d/%d], Loss: %.4f, Accuracy: %.2f %%'
              % (epoch , num_epochs,
                 total_loss, 100 * correct/total))
            all_losses.append([epoch,mean_loss])
            train_acc_list.append([epoch,correct/total])
        filter_loader = torch.utils.data.DataLoader(train_dataset, batch_size=1, shuffle=False)
        sample_errors=[]
        mean_error=0
       # print('doing error statistic')
        prob=[k.item() for k in raw]
        
    
        error=[]
        for i in range(Y.shape[0]):          #the e2 error function
            if correct_mask[i]:
                error.append(-prob[i])
            else:
                error.append(prob[i])
        # the e1 error function        
        #error=[1-prob[i] if correct_mask[i] else prob[i] for i in range(Y.shape[0])]
            
        sample_errors=np.array(error)
        #normalize the error from 0 to 1
        sample_errors=(sample_errors-sample_errors.min())/(sample_errors.max()-sample_errors.min())
        mean_error=np.mean(sample_errors) 
        var=sample_errors.var()  #varaince of the error
        var_list.append(var)
        if epoch==0:            #choose some of the epoch for BDR histogram visualisation
            err_0=sample_errors
            X_0=train_data
        if epoch==300:
            err_300=sample_errors
        if epoch==350:
            err_350=sample_errors
        if var<=stop_thresh and early_stop==1:    #training termination condition
#            np.save('alpha_'+str(alpha)+'.npy',train_data)
            print("pattern removed:",320-train_data.shape[0])
            count=0
            for i in range(train_data.shape[0]):
                if np.sum(train_data[i,:-1]==-100)==6:
                    count+=1
            print("Artificial outlier removed:",npattern-count)        
            break #TERMINATE TRAINING !
        if (epoch % 50 == 0 and epoch>0 and bdr==1 and var<=0.1):   # Do we trigger the BDR ?
            sub_errors=[ele for ele in sample_errors if ele > mean_error] #filter out the sub group
            sub_mean_error=sum(sub_errors)/len(sub_errors)
            sub_error_std=np.std(np.array(sub_errors))
            threshold=sub_mean_error+alpha*sub_error_std     #compute the final remove threshold
            sample_errors=np.array(sample_errors)
            mask_idx=np.where(sample_errors<threshold)[0]
            train_data=train_data[mask_idx]        #throw away some of the patterns
            trigger.append([epoch,var])
            if epoch == 300:
                thresh_300=threshold
                m_err_300=np.mean(err_300)
                m_s_err_300=sub_mean_error
                X_300=train_data
            if epoch == 350:
                thresh_350=threshold
                m_err_350=np.mean(err_350)
                m_s_err_350=sub_mean_error
                X_350=train_data    
            
           
            print("Remove",str(len(filter_loader)-len(mask_idx)))
        test_dataset=DataFrameDataset(test_data)    
        test_loader=torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, shuffle=True)
        if epoch%1==0:
            test_error=0 
            net.eval()
            test_total=0
            test_correct=0
#            for step, (batch_x, batch_y) in enumerate(test_loader):
            X = torch.Tensor(test_data[:,:-1]).float()
            Y = torch.Tensor(test_data[:,-1]).long()
            outputs = net(X)
            
    
            _, predicted = torch.max(F.softmax(outputs), 1)
            loss_test=criterion(outputs,Y)
            test_error+=loss_test.item()
            # calculate and print accuracy
            test_total = test_total + predicted.size(0)
            test_correct = test_correct + sum(predicted.data.numpy() == Y.data.numpy())
            test_acc= test_correct/test_total
            print("test acc:",100*test_acc,"%")          
            mean_test_error=test_error/X.shape[0] 
            test_losses.append([epoch,mean_test_error])
            test_acc_list.append([epoch,test_acc])
    
    total=0
    correct=0
    for step, (batch_x, batch_y) in enumerate(test_loader): #FINAL TEST
            X = batch_x
            Y = batch_y.long()
            outputs = net(X)
            
            
            _, predicted = torch.max(F.softmax(outputs), 1)
            # calculate and print accuracy
            total = total + predicted.size(0)
            correct = correct + sum(predicted.data.numpy() == Y.data.numpy())
    print("final test acc:",100*correct/total,"%") 
    all_losses=np.array(all_losses)
    test_losses=np.array(test_losses)   
    train_acc_np=np.array(train_acc_list)
    test_acc_np=np.array(test_acc_list)
###PLOT CODE BLOCK, UNCOMMENT THE CORRESPONDING BLOCK BASED ON YOUR NEED####    

    ## PLOT THE VARIANCE ALONG WITH EPOCH##############
    plt.figure(2)
    plt.plot(var_list,label='varaince')
    trigger=np.array(trigger)
    plt.plot(trigger[:,0],trigger[:,1],'*',markersize=15,label='BDR trigger point')
    plt.title('Average pattern error variance accroding to epoch')
    plt.xlabel('epoch')
    plt.ylabel('varaince')
    plt.legend()
    plt.grid()
    #########################
    ####PLOT THE BIMODAL DISTRIBUTION EFFECT ###
    plt.figure(3)
    plt.subplot(311)
    plt.hist(err_0,10)
    plt.subplot(312)
    plt.hist(err_300,10)
    plt.vlines(thresh_300,0,100,'r',label='threshold')
    plt.legend(loc='center')
    plt.xlabel('error')
    plt.ylabel('number of patterns')
    plt.title('epoch=300')
    plt.subplot(313)
    plt.hist(err_350,10)
    plt.vlines(thresh_350,0,192,'r',label='threshold')
    plt.legend(loc='center')
    plt.xlabel('error')
    
    plt.title('epoch=350')
    ######################
    ####PLOT ACCURACY CURVE OF BDR AND NORMAL###
#    base_train_acc=np.load('base_train_acc.npy')
#    base_test_acc=np.load('base_test_acc.npy')
#    bdr_train_acc=np.load('bdr_train_acc.npy')
#    bdr_test_acc=np.load('bdr_test_acc.npy')
#    plt.figure(4)
#    plt.plot(base_train_acc[:,0],base_train_acc[:,1],'m',label='train')
#    plt.plot(base_test_acc[:,0],base_test_acc[:,1],'r',label='test')
#    plt.plot(bdr_train_acc[:,0],bdr_train_acc[:,1],'b',label='bdr_train')
#    plt.plot(bdr_test_acc[:,0],bdr_test_acc[:,1],'y',label='bdr_test')
#    plt.legend(loc=4)
#    plt.grid()
#    plt.title("Accuracy curve")
#    plt.xlabel('epoch')
#    plt.ylabel('Accuracy')
    
    
     ######################
    ####PLOT ACCURACY BDR PREPROCESSING###
   
#    plt.figure(4)
#    plt.plot(train_acc_np[:,0],train_acc_np[:,1],'m',label='train')
#    plt.plot(test_acc_np[:,0],test_acc_np[:,1],'r',label='test')
#  
#    plt.legend(loc=4)
#    plt.grid()
#    plt.title("Accuracy curve")
#    plt.xlabel('epoch')
#    plt.ylabel('Accuracy')
#    
