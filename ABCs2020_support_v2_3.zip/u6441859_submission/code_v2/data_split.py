# -*- coding: utf-8 -*-
"""
Created on Thu May 14 20:52:00 2020

@author: HP
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.utils.data
import csv
import random
np.random.seed(100)
torch.manual_seed(100)

omit_list=[['O15','F1'],['O1','T1'],['O2','F2'],['O11','F2'],['O5','F4'],
           ['O6','F5'],['O15','F6'],['O2','T2'],['O3','T2'],['O5','T7']]

data=[]
with open('Anger.csv',encoding='utf-8') as csvfile:
  spamreader = csv.reader(csvfile)
  for row in spamreader:
      data.append(row)
data=data[1:]
#raw_data=[x[2:] for x in data ]
raw_data=data
id_matrix=[]
for ele in raw_data:
    if ele[-1]=='Genuine':
        ele[-1]=0
    else:
        ele[-1]=1
    dim=8
    for i in range(2,8):
        ele[i]=float(ele[i])


random.Random(98).shuffle(raw_data)   

raw_data=[x for x in raw_data if x[0:2] not in omit_list]
raw_data=[x[2:] for x in raw_data ]
raw_data=np.array(raw_data)
raw_data=(raw_data-raw_data.min(0))/(raw_data.max(0)-raw_data.min(0))
raw_data=list(raw_data)
train_data=np.array(raw_data[:int(0.8*len(raw_data))])
test_data=np.array(raw_data[int(0.8*len(raw_data)):])


np.save('train.npy',train_data)
np.save('test.npy',test_data)




