# -*- coding: utf-8 -*-
"""
Created on Thu May 14 14:30:33 2020

@author: HP
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.utils.data
import random
from matplotlib import pyplot as plt
import torch.nn.functional as F
torch.manual_seed(100)
np.random.seed(100)
random.seed(100)
# Hyper Parameters
input_size = 186
hidden_size = 60
feature_num=2
num_classes = 2
num_epochs = 1000
batch_size = 10
learning_rate = 5e-3
alpha=0.1    #std distance
bdr=0        # make it as 1 if you want to use BDR
early_stop=0 # make it as 1 if you want to use BDR
stop_thresh=0.05 #training stop variance threshold
npattern=0 #number of Artificial outlier


    
    
def Diff(x):
    
    data=np.diff(x,axis=1)
    
    return data
        
    

 # Neural Network,the skeleton is from the lab code
class Net(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.activate = nn.ReLU()    #the activation function can be changed
        self.fc2 = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        out = self.fc1(x)
        out = self.activate(out)
        out = self.fc2(out)
        return out
    
class FusionNet(nn.Module):
    def __init__(self,input_size, hidden_size, feature_num,num_classes):
        super(FusionNet, self).__init__()
        self.pupnet=Net(input_size,hidden_size,feature_num)
        self.diffnet=Net(input_size-1,hidden_size,feature_num)
        self.activate=nn.ReLU()
        self.fc1=nn.Linear(feature_num*2,num_classes)
    def forward(self,x,y):
        pup_feature=self.pupnet(x)
        diff_feature=self.diffnet(y)
        feature=torch.cat((pup_feature,diff_feature),1)
        feature=self.activate(feature)
        out=self.fc1(feature)
        
        return out
            


net = Net(input_size, hidden_size, num_classes)

#net=FusionNet(input_size, hidden_size, feature_num,num_classes)
# Loss and Optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate,weight_decay=1e-5)

train_data_r=np.load('train_right.npy')
train_data_l=np.load('train_left.npy')


test_data_r=np.load('test_right.npy')
test_data_l=np.load('test_left.npy')


# train the model by batch
if __name__=='__main__':
    var_list=[]
    all_losses = []
    test_losses=[]
    train_acc_list=[]
    test_acc_list=[]
    trigger=[]
    for epoch in range(num_epochs):   #training part, inspired by the lab code
        total = 0
        correct = 0
        total_loss = 0
        X = torch.tensor(train_data_l[:,:-1]).float()
#        D = torch.tensor(Diff(train_data_l[:,:-1])).float()
#        X = torch.tensor(train_data_r[:,:-1]).float()
      #  D = torch.tensor(Diff(train_data_r[:,:-1])).float()
        Y = torch.tensor(train_data_l[:,-1]).long()
        
        
        optimizer.zero_grad()  
        outputs = net(X)
      #  outputs = net(X,D)
        loss = criterion(outputs, Y)
        
        loss.backward()
        optimizer.step()
        prob=F.softmax(outputs,1)
        raw, predicted = torch.max(F.softmax(outputs,1),1) #use softmax to produce probability
        # calculate and print accuracy
        total = total + predicted.size(0)
        correct_mask=predicted.data.numpy() == Y.data.numpy()
        correct = correct + sum(predicted.data.numpy() == Y.data.numpy())
        total_loss = total_loss + loss.item()
        mean_loss=total_loss/(X.shape[0])
        
        if epoch%1==0:
            print('Epoch [%d/%d], Loss: %.4f, Accuracy: %.2f %%'
              % (epoch , num_epochs,
                 total_loss, 100 * correct/total))
            all_losses.append([epoch,mean_loss])
            train_acc_list.append([epoch,correct/total])
        if epoch%1==0:
            test_error=0 
            net.eval()
            test_total=0
            test_correct=0
#            for step, (batch_x, batch_y) in enumerate(test_loader):
            X = torch.Tensor(test_data_l[:,:-1]).float()
#            D= torch.Tensor(Diff(test_data_l[:,:-1])).float()
#            X = torch.Tensor(test_data_r[:,:-1]).float()
            D=torch.Tensor(Diff(test_data_r[:,:-1])).float()
            Y = torch.Tensor(test_data_l[:,-1]).long()
            outputs = net(X)
           # outputs = net(X,D)
            
    
            _, predicted = torch.max(F.softmax(outputs), 1)
            loss_test=criterion(outputs,Y)
            test_error+=loss_test.item()
            # calculate and print accuracy
            test_total = test_total + predicted.size(0)
            test_correct = test_correct + sum(predicted.data.numpy() == Y.data.numpy())
            test_acc= test_correct/test_total
            print("test acc:",100*test_acc,"%")          
            mean_test_error=test_error/X.shape[0] 
            test_losses.append([epoch,mean_test_error])
            test_acc_list.append([epoch,test_acc])
    
#    total=0
#    correct=0
#    for step, (batch_x, batch_y) in enumerate(test_loader): #FINAL TEST
#            X = batch_x
#            Y = batch_y.long()
#            outputs = net(X)
#            
#            
#            _, predicted = torch.max(F.softmax(outputs), 1)
#            # calculate and print accuracy
#            total = total + predicted.size(0)
#            correct = correct + sum(predicted.data.numpy() == Y.data.numpy())
#    print("final test acc:",100*correct/total,"%") 
#    all_losses=np.array(all_losses)
#    test_losses=np.array(test_losses)   
#    train_acc_np=np.array(train_acc_list)
#    test_acc_np=np.array(test_acc_list)
###PLOT CODE BLOCK, UNCOMMENT THE CORRESPONDING BLOCK BASED ON YOUR NEED####    

    ## PLOT THE VARIANCE ALONG WITH EPOCH##############
#    plt.figure(2)
#    plt.plot(var_list,label='varaince')
#    trigger=np.array(trigger)
#    plt.plot(trigger[:,0],trigger[:,1],'*',markersize=15,label='BDR trigger point')
#    plt.title('Average pattern error variance accroding to epoch')
#    plt.xlabel('epoch')
#    plt.ylabel('varaince')
#    plt.legend()
#    plt.grid()
    #########################
    ####PLOT THE BIMODAL DISTRIBUTION EFFECT ###
#    plt.figure(3)
#    plt.subplot(311)
#    plt.hist(err_0,10)
#    plt.subplot(312)
#    plt.hist(err_300,10)
#    plt.vlines(thresh_300,0,100,'r',label='threshold')
#    plt.legend(loc='center')
#    plt.xlabel('error')
#    plt.ylabel('number of patterns')
#    plt.title('epoch=300')
#    plt.subplot(313)
#    plt.hist(err_350,10)
#    plt.vlines(thresh_350,0,192,'r',label='threshold')
#    plt.legend(loc='center')
#    plt.xlabel('error')
#    
#    plt.title('epoch=350')
    ######################
    ####PLOT ACCURACY CURVE OF BDR AND NORMAL###
#    base_train_acc=np.load('base_train_acc.npy')
#    base_test_acc=np.load('base_test_acc.npy')
#    bdr_train_acc=np.load('bdr_train_acc.npy')
#    bdr_test_acc=np.load('bdr_test_acc.npy')
#    plt.figure(4)
#    plt.plot(base_train_acc[:,0],base_train_acc[:,1],'m',label='train')
#    plt.plot(base_test_acc[:,0],base_test_acc[:,1],'r',label='test')
#    plt.plot(bdr_train_acc[:,0],bdr_train_acc[:,1],'b',label='bdr_train')
#    plt.plot(bdr_test_acc[:,0],bdr_test_acc[:,1],'y',label='bdr_test')
#    plt.legend(loc=4)
#    plt.grid()
#    plt.title("Accuracy curve")
#    plt.xlabel('epoch')
#    plt.ylabel('Accuracy')
    
    
     ######################
    ####PLOT ACCURACY BDR PREPROCESSING###
   
#    plt.figure(4)
#    plt.plot(train_acc_np[:,0],train_acc_np[:,1],'m',label='train')
#    plt.plot(test_acc_np[:,0],test_acc_np[:,1],'r',label='test')
#  
#    plt.legend(loc=4)
#    plt.grid()
#    plt.title("Accuracy curve")
#    plt.xlabel('epoch')
#    plt.ylabel('Accuracy')
#    
