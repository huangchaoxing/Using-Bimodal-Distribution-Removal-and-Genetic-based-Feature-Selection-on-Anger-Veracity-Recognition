# -*- coding: utf-8 -*-
"""
Created on Thu May 14 12:58:40 2020

@author: HP
"""

import numpy as np
import pandas as pd
import csv
data=[]
#with open('anger_v2/L_F1.csv',encoding='utf-8') as csvfile:
#  spamreader = csv.reader(csvfile)
#  for row in spamreader:
#      data.append(row)
#      
#data=[x[:20] for x in data ]     
#data=data[1:] 
#data=np.array(data)


def get_sample(sample_id,eye):
    
    label=sample_id[-1]
    video_id=sample_id[0]
    ob_id=sample_id[1]-1
    if video_id>0:
        video_key='anger_v2/'+eye+'_T'+str(video_id)+'.csv'
    else:
        video_key='anger_v2/'+eye+'_F'+str(abs(video_id))+'.csv'
    data=[]    
    with open(video_key,encoding='utf-8') as csvfile:
       spamreader = csv.reader(csvfile)
       for row in spamreader:
           data.append(row)   
    data=data[1:] 
    data=[x[:20] for x in data ]     
    data=np.array(data)   
    sample=data[:,ob_id]
    sample=list(sample)
    sample=[x for x in sample if x!='']
    sample.append(label)
    sample=np.array(sample)
    sample=sample.astype('float')
    
    return sample
#sample_id=np.array([-1,1,1])
#sample=get_sample(sample_id,'L')

train_id=np.load('train_id.npy')
test_id=np.load('test_id.npy')
left_train=[]
right_train=[]
left_test=[]
right_test=[]
for i in range(train_id.shape[0]):
    left_sample=get_sample(train_id[i,:],'L')
    right_sample=get_sample(train_id[i,:],'R')
    left_train.append(left_sample)
    right_train.append(right_sample)
    
for i in range(test_id.shape[0]):
    left_sample=get_sample(test_id[i,:],'L')
    right_sample=get_sample(test_id[i,:],'R')
    left_test.append(left_sample)
    right_test.append(right_sample)    
    
    
max_train_length=max([x.shape[0] for x in left_train])-1
max_test_length=max([x.shape[0] for x in left_test])-1

max_length=max([max_train_length,max_test_length])

for i in range(len(left_train)):
    
    sample=left_train[i]
    label=sample[-1]
    data=sample[:-1]
    padding=np.zeros(max_length-data.shape[0])
    data=np.hstack((data,padding,))
    left_train[i]=np.hstack((data,label))
    
for i in range(len(right_train)):
    
    sample=right_train[i]
    label=sample[-1]
    data=sample[:-1]
    padding=np.zeros(max_length-data.shape[0])
    data=np.hstack((data,padding,))
    right_train[i]=np.hstack((data,label))    
    
for i in range(len(left_test)):
    
    sample=left_test[i]
    label=sample[-1]
    data=sample[:-1]
    padding=np.zeros(max_length-data.shape[0])
    data=np.hstack((data,padding,))
    left_test[i]=np.hstack((data,label))     
    
for i in range(len(right_test)):
    
    sample=right_test[i]
    label=sample[-1]
    data=sample[:-1]
    padding=np.zeros(max_length-data.shape[0])
    data=np.hstack((data,padding,))
    right_test[i]=np.hstack((data,label))     
    
    
np.save('train_left.npy',np.array(left_train))
np.save('train_right.npy',np.array(right_train))
np.save('test_left.npy',np.array(left_test))
np.save('test_right.npy',np.array(right_test))
    
    
    

    
    