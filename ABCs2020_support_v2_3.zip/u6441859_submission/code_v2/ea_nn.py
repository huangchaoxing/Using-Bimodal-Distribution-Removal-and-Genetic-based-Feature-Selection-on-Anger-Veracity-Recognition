# -*- coding: utf-8 -*-
"""
Created on Wed May 13 16:56:57 2020

@author: HP
"""

import numpy as np
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
import torch
import torch.nn as nn
import torch.utils.data
import random
from matplotlib import pyplot as plt
import torch.nn.functional as F
from operator import itemgetter
from sklearn.metrics import accuracy_score
random.seed(100)
torch.manual_seed(100)
np.random.seed(100)

train_data=np.load('train_left.npy')
test_data=np.load('test_left.npy')


POPULATION=21
MUTE_RATE=0.001
 # Neural Network,the skeleton is from the lab code
class Net(nn.Module):
    def __init__(self, input_size, hidden_size, num_classes):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.activate = nn.ReLU()    #the activation function can be changed
        self.fc2 = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        out = self.fc1(x)
        out = self.activate(out)
        out = self.fc2(out)
        return out


def fitness(chrom): #This fitness function is for feature selection and architecture selection
    input_num=sum(chrom)
    mask=np.argwhere(np.array(chrom))
    mask_idx=[[x[0] for x in mask]]
    train_X=train_data[:,:-1]
    train_X=train_X[:,mask_idx]
    test_X=test_data[:,:-1]
    test_X=test_X[:,mask_idx]
    train_y=train_data[:,-1]
    test_y=test_data[:,-1]
    train_X=train_X.squeeze(1)
    test_X=test_X.squeeze(1)
    random.seed(100)
    torch.manual_seed(100)
    np.random.seed(100)
    model=Net(input_num,60,2)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=5e-3,weight_decay=1e-5)
    model.train()
    train_num=train_X.shape[0]
    for epoch in range(1000):   #training part, inspired by the lab code
        optimizer.zero_grad()  
        X=torch.tensor(train_X[:int(0.8*train_num),:]).float()
        y=torch.tensor(train_y[:int(0.8*train_num)]).long()
        outputs = model(X)
        loss = criterion(outputs, y)
        
        loss.backward()
        optimizer.step()
        raw, predicted = torch.max(F.softmax(outputs,1),1)
 
    model.eval()
    X=torch.tensor(train_X[int(0.8*train_num):,:]).float()
    y=torch.tensor(train_y[int(0.8*train_num):]).long()
    pred=model(X)
    raw, pred = torch.max(pred,1)
    correct = sum(pred.data.numpy() == y.data.numpy())
    acc=correct/X.shape[0]
    return acc
    
def fitness_test(chrom):  #This function is for the final training and tesing
    input_num=sum(chrom)
    print(input_num)
    mask=np.argwhere(np.array(chrom))
    mask_idx=[[x[0] for x in mask]]
    train_X=train_data[:,:-1]
    train_X=train_X[:,mask_idx]
    test_X=test_data[:,:-1]
    test_X=test_X[:,mask_idx]
    train_y=train_data[:,-1]
    test_y=test_data[:,-1]
    train_X=train_X.squeeze(1)
    test_X=test_X.squeeze(1)
    random.seed(100)
    torch.manual_seed(100)
    np.random.seed(100)
    model=Net(input_num,60,2)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=5e-3,weight_decay=1e-5)
    model.train()
    for epoch in range(1000):   #training part, inspired by the lab code
        optimizer.zero_grad()  
        X=torch.tensor(train_X).float()
        y=torch.tensor(train_y).long()
        outputs = model(X)
        loss = criterion(outputs, y)
        
        loss.backward()
        optimizer.step()
        raw, predicted = torch.max(F.softmax(outputs,1),1)
 
    model.eval()
    X=torch.tensor(test_X).float()
    y=torch.tensor(test_y).long()
    pred=model(X)
    raw, pred = torch.max(pred,1)
    correct = sum(pred.data.numpy() == y.data.numpy())
    acc=correct/X.shape[0]
    return acc

def fitness_list(population):
    fitness_list=[]
    for chrom in population:
        fitness_list.append([chrom,fitness(chrom)])
        
    return fitness_list    

def crossover(dad,mom): #Generate two offsprings in cross over
    l=len(dad)
    cross_idx=random.randint(0,l)
    child_a=dad[0:cross_idx]+mom[cross_idx:l]
    child_b=mom[0:cross_idx]+dad[cross_idx:l]
    
    return child_a,child_b

def tournament_selection(total_population): #select members to form a tourament
    
    member_idx=random.sample(range(POPULATION),9)
    members=[total_population[i] for i in member_idx]
    total_fitness=0
    for i in range(len(members)):
        total_fitness+=members[i][1]
    selection_prob=[chrom[1]/total_fitness for chrom in members]    
    
    return members,selection_prob

def mutation(chrom,mute_rate):  #mutation
    l=len(chrom)
    flag=random.choice(list(range(int(1/mute_rate))))==0
    if flag:
        change_idx=random.sample(range(l),1)
        change_idx=change_idx[0]
        if chrom[change_idx]==1:
            chrom[change_idx]=0
        else:
            chrom[change_idx]=1
    if sum(chrom)==0:
        change_idx=random.sample(range(l),1)   
        change_idx=change_idx[0]
        chrom[change_idx]=1
    return chrom        

def tournament_reproduction(total_population,mute_rate): #reproduction within one tourament
    
    members,selection_prob=tournament_selection(total_population)
    dad_idx,mom_idx=np.random.choice(9,2,selection_prob)
    dad=members[dad_idx]
    mom=members[mom_idx]
    child_a,child_b= crossover(dad[0],mom[0]) 

    child_a=mutation(child_a,mute_rate)
    child_b=mutation(child_b,mute_rate)
   
    return child_a,child_b


def ga(population,num_gen,mute_rate,tour_num):
    winner_score=[]
    new_gen=population
    for i in range(num_gen):
        print(i)
        pop=fitness_list(new_gen)
        pop=sorted(pop,key=itemgetter(1))
        new_gen=[]
        new_gen.append(pop[-1][0])
        winner_score.append(pop[-1][1])
        for j in range(tour_num): #We select many tournament
           child_a,child_b=tournament_reproduction(pop,mute_rate)
           new_gen.append(child_a)
           new_gen.append(child_b)
           
           
    return new_gen,winner_score  
            
   

population=[]    
for i in range(POPULATION):                #Initialize population
    chrom=[random.randint(0,1) for i in range (186)]
    if chrom==[0]*186:
        chrom=[1]+[0]*185
    population.append(chrom)    
#population.append([1]*186)    
tour_num=int((POPULATION-1)/2)
mute_rate=MUTE_RATE
num_gen=10
new_gen,winner_score=ga(population,num_gen,mute_rate,tour_num) #Run GA

fittest=sorted(fitness_list(new_gen),key=itemgetter(1))

fit=fitness_test(fittest[-1][0]) #Final train
#fit=fitness_test([1,1,1,1,1,1])
